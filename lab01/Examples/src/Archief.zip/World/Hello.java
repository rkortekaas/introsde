package World;

public class Hello {
    public static String helloMessage = "Hello World!";
    public static void main(String args[]){
        System.out.println(helloMessage);
    }
}